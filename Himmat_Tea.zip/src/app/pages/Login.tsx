'use client';

import React, { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/app/components/ui/button";
import { Input } from "@/app/components/ui/input";
import { Label } from "@/app/components/ui/label";
import { Alert, AlertDescription } from "@/app/components/ui/alert";
import { Eye, EyeOff, AlertCircle, ArrowLeft, ChevronRight } from "lucide-react";
import { toast } from "sonner";
import Image from "next/image";

import { useTranslation } from '../../context/TranslationContext';
export default function Login() {
  const { t } = useTranslation();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { login, isLoggedIn } = useAuth();
  const navigate = useRouter();

  // If already logged in, redirect to dashboard
  useEffect(() => {
    if (isLoggedIn) {
      navigate.push("/himmat_admin_8526/dashboard");
    }
  }, [isLoggedIn, navigate]);

  if (isLoggedIn) {
    return null;
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (!username.trim()) {
      setError(t('login.client.usernameRequired'));
      return;
    }
    if (!password) {
      setError(t('login.client.passwordRequired'));
      return;
    }

    setIsSubmitting(true);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const result = await login(username, password);
    if (result.success) {
      toast.success(t('login.welcomeBack'));
      navigate.push("/himmat_admin_8526/dashboard");
    } else {
      setError(result.error || "Invalid credentials. Please try again.");
    }
    setIsSubmitting(false);
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-white">
      {/* Left Section - Login Form */}
      <div className="flex-1 flex items-center justify-center px-6 sm:px-12 lg:px-20 py-12 bg-white">
        <div className="w-full max-w-lg">
          {/* Back Button */}
          <Link
            href="/"
            className="inline-flex items-center gap-2 mb-12 text-[#78746e] hover:text-[#2d5a3d] transition-all duration-200"
          >
            <ArrowLeft className="h-4 w-4" />
            <span className="text-sm font-medium">{t('auth.backToHome')}</span>
          </Link>

          {/* Logo */}
          <Image
            src="/logo.svg"
            alt={t('auth.logoAlt')}
            width={140}
            height={140}
            className="w-auto h-[56px] mb-10"
          />

          {/* Header */}
          <div className="mb-8">
            <h1
              className="text-4xl font-semibold text-[#1c1917] mb-3 leading-tight"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Welcome back
            </h1>
            <p className="text-[#6d6a63] text-lg leading-7">
              Sign in to your admin dashboard
            </p>
          </div>

          {error && (
            <Alert variant="destructive" role="alert" className="mb-8 border-red-200 bg-red-50 text-red-800 rounded-xl">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <form onSubmit={handleSubmit} className="space-y-5" noValidate>
            <div className="space-y-2">
              <Label 
                htmlFor="username" 
                className="text-[#1c1917] text-sm font-medium"
              >
                Username or Email
              </Label>
              <Input
                id="username"
                name="username"
                type="text"
                placeholder={t('auth.enterUsernameOrEmail')}
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                  setError("");
                }}
                required
                aria-describedby={error ? "username-error" : undefined}
                aria-invalid={!!error}
                disabled={isSubmitting}
                className="h-12 px-4 rounded-xl border-[#e8e9e5] bg-[#fafaf8] focus:border-[#2d5a3d] focus:ring-2 focus:ring-[#2d5a3d]/10 transition-all duration-200 text-[#1c1917] placeholder:text-[#b0aba4] hover:border-[#d4d6cf]"
              />
            </div>

            <div className="space-y-2">
              <Label 
                htmlFor="password" 
                className="text-[#1c1917] text-sm font-medium"
              >
                Password
              </Label>
              <div className="relative">
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? "text" : "password"}
                  placeholder={t('auth.login.passwordPlaceholder')}
                  value={password}
                  onChange={(e) => {
                    setPassword(e.target.value);
                    setError("");
                  }}
                  required
                  aria-describedby={error ? "password-error" : undefined}
                  aria-invalid={!!error}
                  disabled={isSubmitting}
                  className="h-12 px-4 pr-12 rounded-xl border-[#e8e9e5] bg-[#fafaf8] focus:border-[#2d5a3d] focus:ring-2 focus:ring-[#2d5a3d]/10 transition-all duration-200 text-[#1c1917] placeholder:text-[#b0aba4] hover:border-[#d4d6cf]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-[#a1a09b] hover:text-[#2d5a3d] transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  {showPassword ? (
                    <EyeOff className="h-4 w-4" />
                  ) : (
                    <Eye className="h-4 w-4" />
                  )}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full cursor-pointer h-12 bg-[#2d5a3d] hover:bg-[#244a33] text-white text-base font-medium rounded-xl transition-all duration-200 shadow-lg shadow-[#2d5a3d]/20 hover:shadow-xl hover:shadow-[#2d5a3d]/25 active:scale-[0.99]"
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <div className="flex items-center gap-2">
                  <div className="h-4 w-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  <span>{t('auth.login.submitting')}</span>
                </div>
              ) : (
                <div className="flex items-center justify-center gap-2">
                  <span>{t('auth.login.submit')}</span>
                  <ChevronRight className="h-4 w-4" />
                </div>
              )}
            </Button>
          </form>
        </div>
      </div>

      {/* Right Section - Branding Panel */}
      <div className="hidden lg:flex flex-1 relative overflow-hidden bg-[#2d5a3d]">
        <div className="h-full w-full flex flex-col justify-end p-16">
          <div className="max-w-md">
            <span className="inline-flex items-center rounded-full bg-white/10 px-4 py-2 text-[11px] uppercase tracking-[0.32em] font-semibold text-[#d8e5ce] border border-white/10 mb-8">
              Himmat Tea
            </span>
            <h2
              className="text-5xl lg:text-6xl font-semibold text-white mb-5 leading-tight"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Crafting the perfect cup
            </h2>
            <p className="text-[#d8e5ce] text-lg leading-relaxed mb-10">
              Experience the art of tea with Himmat Tea. From the finest plantations to your cup.
            </p>

            <div className="grid grid-cols-3 gap-6">
              <div>
                <div className="text-3xl font-bold text-[#c8a96e]">50+</div>
                <div className="text-sm text-[#d8e5ce] mt-1">{t('auth.stats.teaVarieties')}</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#c8a96e]">10K+</div>
                <div className="text-sm text-[#d8e5ce] mt-1">{t('testimonials.stat.customersLabel')}</div>
              </div>
              <div>
                <div className="text-3xl font-bold text-[#c8a96e]">15+</div>
                <div className="text-sm text-[#d8e5ce] mt-1">{t('auth.stats.yearsOfExcellence')}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
