
export const BRAND = {
  companyName: "Godgifted",
  legalName: "Godgifted Pvt. Ltd.",
  domain: "godgifted.com",
  supportEmail: "info@darbartech.com",
  supportPhone: "+977-98XXXXXXXX",
  tagline: "Pure, Traceable, God-Gifted.",
  socialLinks: {
    instagram: "https://instagram.com/himmattea",
    facebook: "https://facebook.com/himmattea",
    youtube: "https://youtube.com/@himmattea",
  },
  productLines: [
    {
      slug: "himmat-tea",
      name: "Himmat Tea",
      category: "tea",
      description: "Hand-sourced tea from the Himalayan foothills and beyond.",
      color: "#2d5a3d",
      subcategories: ["green", "black", "herbal", "oolong", "white", "tea-sets"]
    },
    {
      slug: "godgifted-dal",
      name: "Godgifted Dal",
      category: "dal",
      description: "Stone-ground, unpolished pulses sourced directly from farmers.",
      color: "#b8862f",
      subcategories: ["toor", "moong", "chana", "masoor", "urad", "gift-hampers"]
    }
  ]
};
