'use client';

import React, { useState, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useRouter } from 'next/navigation';
import { ArrowRight, Mail } from 'lucide-react';
import { createForgotPasswordSchema, ForgotPasswordData } from './validation';
import { useTranslation } from '@/hooks/useTranslation';
import { notify } from '@/lib/notify';
import { LoadingButton } from '@/app/components/ui/loading-button';

interface ForgotPasswordFormProps {
  className?: string;
}

export const ForgotPasswordForm: React.FC<ForgotPasswordFormProps> = ({
  className = ''
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const router = useRouter();
  const { t } = useTranslation();

  const forgotPasswordSchema = useMemo(() => createForgotPasswordSchema(t), [t]);

  const {
    register,
    handleSubmit,
    formState: { errors }
  } = useForm<ForgotPasswordData>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: { email: '' }
  });

  const onSubmit = async (data: ForgotPasswordData) => {
    setIsLoading(true);
    setApiError(null);

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: data.email })
      });

      const result = await response.json();

      if (!response.ok) {
        const errorCode = result.rawError || result.error || result.message;
        const isAccountNotFound =
          response.status === 404 ||
          errorCode === 'AUTH_EMAIL_NOT_FOUND' ||
          (typeof errorCode === 'string' && errorCode.includes('No account found'));
        if (isAccountNotFound) {
          throw new Error(t('auth.forgotPassword.accountNotFound'));
        }
        throw new Error(t('auth.forgotPassword.genericError'));
      }

      router.push(`/verify-reset?email=${encodeURIComponent(data.email.trim())}`);
    } catch (error) {
      setApiError(
        error instanceof Error
          ? error.message
          : t('auth.forgotPassword.genericError')
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className={`w-full ${className}`}>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-5" noValidate>
        <div>
          <label
            htmlFor="forgot-email"
            className="block text-sm font-medium text-[#1c1917] mb-1.5"
          >
            {t('auth.forgotPassword.emailLabel')}
          </label>
          <div className="relative">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-[#78746e] aria-hidden" />
            <input
              id="forgot-email"
              type="email"
              autoComplete="email"
              aria-describedby={errors.email ? 'forgot-email-error' : undefined}
              aria-invalid={!!errors.email}
              {...register('email')}
              placeholder={t('auth.forgotPassword.emailPlaceholder')}
              className={`w-full pl-12 pr-4 py-3 rounded-xl border transition-colors text-sm focus:outline-none
                ${errors.email
                  ? 'border-red-300 bg-red-50 focus:border-red-500'
                  : 'border-[rgba(28,25,23,0.12)] bg-[#f9f7f4] focus:border-[#2d5a3d]'
                }
              `}
            />
          </div>
          {errors.email && (
            <p
              id="forgot-email-error"
              className="mt-1.5 text-sm text-red-600"
              role="alert"
            >
              {errors.email.message}
            </p>
          )}
        </div>

        {apiError && (
          <div
            className="p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm"
            role="alert"
            aria-live="polite"
          >
            {apiError}
          </div>
        )}

        <LoadingButton
          type="submit"
          isLoading={isLoading}
          loadingLabel={t('auth.forgotPassword.submitting')}
          aria-disabled={isLoading}
          className="w-full py-4 bg-[#2d5a3d] text-white font-semibold rounded-xl hover:bg-[#234832] transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {t('auth.forgotPassword.submit')}
          <ArrowRight className="h-5 w-5" />
        </LoadingButton>
      </form>
    </div>
  );
};

export default ForgotPasswordForm;
